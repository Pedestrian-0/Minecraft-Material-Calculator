# -*- coding: utf-8 -*-
"""
Minecraft Material Calculator - GUI v2 (tkinter, nessuna installazione extra).
Metti questo file nella STESSA cartella di minecraft_calc.py e fai doppio clic.
"""
import colorsys
import csv
import json
import math
import os
import sys
import zlib
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import minecraft_calc as mc  # noqa: E402

try:  # testo nitido su Windows con schermi ad alta risoluzione
    import ctypes
    ctypes.windll.shcore.SetProcessDpiAwareness(1)
except Exception:
    pass

FONT, MONO = "Segoe UI", "Consolas"
UNIT_MODES = ["Pezzi + stack", "Solo pezzi", "Shulker box", "Double chest"]

PALETTES = {
    "Scuro": dict(bg="#11151a", panel="#181d24", card="#1f262f", row2="#232c36", border="#2e3844",
                  fg="#e8eef4", muted="#8a97a6", accent="#4ade80", accent_h="#6ee79b",
                  on_accent="#06210f", accent2="#38bdf8", amber="#fbbf24", warn="#f87171",
                  entry="#141a21", sel="#2c4a3b", dark=True),
    "Chiaro": dict(bg="#eef1f4", panel="#ffffff", card="#ffffff", row2="#f3f6f9", border="#d3dae1",
                   fg="#18222d", muted="#5d6a78", accent="#16a34a", accent_h="#22c55e",
                   on_accent="#ffffff", accent2="#0369a1", amber="#b45309", warn="#dc2626",
                   entry="#ffffff", sel="#cfeedd", dark=False),
}


def stk(n, item):
    ss = mc.stack_size(item)
    if ss == 1 or n < ss:
        return mc.fmt(n)
    s, r = divmod(n, ss)
    return f"{mc.fmt(s)} st" + (f" + {r}" if r else "")


def int_of(var, default, lo=0, hi=10 ** 9):
    try:
        return max(lo, min(hi, int(var.get())))
    except (ValueError, tk.TclError):
        return default


class ItemList(ttk.Frame):
    """Campo oggetto (con suggerimenti) + lista modificabile. Usata per progetto, inventario, ecc."""

    def __init__(self, master, app, with_qty=True, on_change=None, height=8):
        super().__init__(master)
        self.app, self.with_qty, self.on_change = app, with_qty, on_change
        self.data = {}
        top = ttk.Frame(self)
        top.pack(fill="x")
        self.combo = ttk.Combobox(top, values=app.all_names)
        self.combo.pack(side="left", fill="x", expand=True)
        self.combo.bind("<KeyRelease>", self._filter)
        self.combo.bind("<Return>", lambda e: self.add_from_input())
        if with_qty:
            self.qty = tk.StringVar(value="1")
            sp = ttk.Spinbox(top, from_=1, to=100000000, textvariable=self.qty, width=8)
            sp.pack(side="left", padx=(6, 0))
            sp.bind("<Return>", lambda e: self.add_from_input())
            self.unit = tk.StringVar(value="pezzi")
            ttk.Combobox(top, values=["pezzi", "stack"], textvariable=self.unit,
                         width=6, state="readonly").pack(side="left", padx=(6, 0))
        ttk.Button(top, text="Aggiungi", style="Accent.TButton",
                   command=self.add_from_input).pack(side="left", padx=(6, 0))

        wrap = ttk.Frame(self)
        wrap.pack(fill="both", expand=True, pady=(8, 4))
        cols = ("item", "qty") if with_qty else ("item",)
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings", height=height)
        self.tree.heading("item", text="Oggetto", anchor="w")
        self.tree.column("item", width=200, anchor="w")
        if with_qty:
            self.tree.heading("qty", text="Quantita'", anchor="e")
            self.tree.column("qty", width=110, anchor="e")
            self.tree.bind("<Double-1>", self._edit)
        sb = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.tree.pack(side="left", fill="both", expand=True)
        self.tree.bind("<Delete>", lambda e: self.remove_selected())
        app.trees.append(self.tree)

        row = ttk.Frame(self)
        row.pack(fill="x")
        ttk.Button(row, text="Rimuovi", command=self.remove_selected).pack(side="left")
        ttk.Button(row, text="Svuota", command=self.clear).pack(side="left", padx=6)
        if with_qty:
            ttk.Label(row, text="doppio clic = modifica quantita'", style="Muted.TLabel").pack(side="right")

    def _filter(self, event):
        if event.keysym in ("Return", "Up", "Down", "Left", "Right", "Escape", "Tab"):
            return
        t = self.combo.get().strip().lower()
        self.combo["values"] = [n for n in self.app.all_names if t in n.lower()] if t else self.app.all_names

    def changed(self):
        self.refresh()
        if self.on_change:
            self.on_change()

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        for i, (name, n) in enumerate(self.data.items()):
            vals = (mc.pretty(name), mc.fmt(n)) if self.with_qty else (mc.pretty(name),)
            self.tree.insert("", "end", iid=name, values=vals, tags=("odd" if i % 2 else "even",))

    def add_from_input(self):
        name = mc.normalize(self.combo.get())
        if not name:
            return
        n = 1
        if self.with_qty:
            try:
                n = int(self.qty.get().replace(".", "").strip())
                if n <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showwarning("Quantita' non valida", "Inserisci un intero maggiore di 0.")
                return
            if self.unit.get() == "stack":
                n *= mc.stack_size(name)
            self.data[name] = self.data.get(name, 0) + n
        else:
            self.data[name] = 1
        self.combo.set("")
        self.combo["values"] = self.app.all_names
        self.combo.focus_set()
        self.changed()

    def merge(self, d):
        for k, v in d.items():
            self.data[k] = self.data.get(k, 0) + v
        self.changed()

    def set_data(self, d):
        self.data = dict(d)
        self.refresh()

    def remove_selected(self):
        for iid in self.tree.selection():
            self.data.pop(iid, None)
        self.changed()

    def clear(self):
        self.data.clear()
        self.changed()

    def _edit(self, event):
        iid = self.tree.identify_row(event.y)
        if not iid:
            return
        v = simpledialog.askinteger("Quantita'", f"Nuova quantita' per {mc.pretty(iid)}:",
                                    initialvalue=self.data[iid], minvalue=1, maxvalue=10 ** 8,
                                    parent=self)
        if v:
            self.data[iid] = v
            self.changed()


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Minecraft Material Calculator")
        self.geometry("1400x840")
        self.minsize(1120, 700)

        base = mc.build_recipes("oak")
        known = {i for (_, ing, _) in base.values() for i in ing if i not in base}
        self.all_names = sorted({mc.pretty(n) for n in list(base) + list(known)})
        self.style = ttk.Style(self)
        self.trees = []
        self.plan = None
        self.collected, self.done_steps = {}, set()
        self.project_path = None
        self._job, self._loading = None, False
        self.pal = PALETTES["Scuro"]

        self.theme_var = tk.StringVar(value="Scuro")
        self.wood_var = tk.StringVar(value="oak")
        self.fuel_var = tk.StringVar(value="coal")
        self.blast_var = tk.BooleanVar(value=False)
        self.stone_var = tk.BooleanVar(value=False)
        self.auto_var = tk.BooleanVar(value=True)
        self.missing_var = tk.BooleanVar(value=False)
        self.furn_var = tk.IntVar(value=1)
        self.margin_var = tk.IntVar(value=0)
        self.mult_var = tk.IntVar(value=1)
        self.unit_mode = tk.StringVar(value=UNIT_MODES[0])
        self.status = tk.StringVar(value="Pronto.")
        self.card_vars = {}

        self._build_menu()
        self._build_ui()
        self.apply_theme("Scuro")
        for v in (self.wood_var, self.fuel_var, self.blast_var, self.stone_var, self.furn_var,
                  self.margin_var, self.mult_var, self.unit_mode, self.auto_var):
            v.trace_add("write", lambda *a: self.schedule_calc())
        self.bind("<Control-Return>", lambda e: self.calculate())
        self.bind("<F5>", lambda e: self.calculate())
        self.bind("<Control-s>", lambda e: self.save_project())
        self.bind("<Control-o>", lambda e: self.open_project())
        self.bind("<Control-i>", lambda e: self.import_file())
        self.bind("<Control-n>", lambda e: self.new_project())

    # ------------------------------------------------------------ menu
    def _build_menu(self):
        m = tk.Menu(self)
        f = tk.Menu(m, tearoff=0)
        f.add_command(label="Nuovo progetto\tCtrl+N", command=self.new_project)
        f.add_command(label="Apri progetto...\tCtrl+O", command=self.open_project)
        f.add_command(label="Salva progetto\tCtrl+S", command=self.save_project)
        f.add_command(label="Salva con nome...", command=lambda: self.save_project(True))
        f.add_separator()
        f.add_command(label="Importa material list Litematica...\tCtrl+I", command=self.import_file)
        f.add_command(label="Esporta materiali (CSV)...", command=self.export_csv)
        f.add_command(label="Esporta report (TXT)...", command=self.save_text)
        f.add_separator()
        f.add_command(label="Esci", command=self.destroy)
        m.add_cascade(label="File", menu=f)
        v = tk.Menu(m, tearoff=0)
        for name in PALETTES:
            v.add_radiobutton(label=f"Tema {name}", variable=self.theme_var, value=name,
                              command=lambda: self.apply_theme(self.theme_var.get()))
        m.add_cascade(label="Vista", menu=v)
        h = tk.Menu(m, tearoff=0)
        h.add_command(label="Guida rapida", command=self.show_help)
        m.add_cascade(label="Aiuto", menu=h)
        self.config(menu=m)

    # ------------------------------------------------------------ UI
    def _build_ui(self):
        head = ttk.Frame(self, style="Panel.TFrame", padding=(16, 10))
        head.pack(fill="x")
        self.logo = tk.Canvas(head, width=26, height=26, highlightthickness=0)
        self.logo.pack(side="left")
        ttk.Label(head, text="MINECRAFT MATERIAL CALCULATOR", style="Header.TLabel").pack(side="left", padx=10)
        ttk.Label(head, text="Litematica · craft a catena · fornaci", style="HeaderMuted.TLabel").pack(side="left")
        ttk.Button(head, text="Tema", command=self.toggle_theme).pack(side="right")
        ttk.Checkbutton(head, text="Calcolo automatico", variable=self.auto_var,
                        style="Header.TCheckbutton").pack(side="right", padx=12)

        status = ttk.Frame(self, style="Panel.TFrame", padding=(16, 5))
        status.pack(side="bottom", fill="x")
        ttk.Label(status, textvariable=self.status, style="HeaderMuted.TLabel").pack(side="left")

        pw = ttk.PanedWindow(self, orient="horizontal")
        pw.pack(fill="both", expand=True, padx=10, pady=10)
        left = ttk.Frame(pw)
        right = ttk.Frame(pw)
        pw.add(left, weight=0)
        pw.add(right, weight=1)
        self._build_left(left)
        self._build_right(right)

    def _build_left(self, left):
        nb = ttk.Notebook(left)
        nb.pack(fill="both", expand=True)

        t1 = ttk.Frame(nb, padding=10)
        nb.add(t1, text="Progetto")
        ttk.Label(t1, text="Cosa vuoi costruire?", style="H2.TLabel").pack(anchor="w", pady=(0, 6))
        self.targets_list = ItemList(t1, self, True, self.schedule_calc, height=12)
        self.targets_list.pack(fill="both", expand=True)
        lit = ttk.LabelFrame(t1, text="Litematica", padding=8)
        lit.pack(fill="x", pady=(10, 0))
        ttk.Button(lit, text="Importa material list (.csv / .txt)...",
                   command=self.import_file).pack(fill="x")
        ttk.Checkbutton(lit, text="Usa solo i blocchi mancanti (colonna Missing)",
                        variable=self.missing_var).pack(anchor="w", pady=(6, 0))

        t2 = ttk.Frame(nb, padding=10)
        nb.add(t2, text="Inventario")
        ttk.Label(t2, text="Cosa hai gia'?", style="H2.TLabel").pack(anchor="w")
        ttk.Label(t2, text="Quello che hai nei chest viene sottratto dal calcolo,\n"
                           "anche per i pezzi intermedi (es. planks, stone).",
                  style="Muted.TLabel").pack(anchor="w", pady=(0, 8))
        self.have_list = ItemList(t2, self, True, self.schedule_calc, height=14)
        self.have_list.pack(fill="both", expand=True)

        t3 = ttk.Frame(nb, padding=10)
        nb.add(t3, text="Opzioni")
        g = ttk.Frame(t3)
        g.pack(fill="x")
        g.columnconfigure(1, weight=1)

        def row(r, label, widget):
            ttk.Label(g, text=label).grid(row=r, column=0, sticky="w", pady=4, padx=(0, 10))
            widget.grid(row=r, column=1, sticky="ew", pady=4)

        row(0, "Legno ricette generiche", ttk.Combobox(g, values=mc.WOODS, textvariable=self.wood_var, state="readonly"))
        row(1, "Combustibile preferito", ttk.Combobox(g, values=list(mc.FUELS), textvariable=self.fuel_var, state="readonly"))
        row(2, "Fornaci in parallelo", ttk.Spinbox(g, from_=1, to=200, textvariable=self.furn_var, width=8))
        row(3, "Margine extra (%)", ttk.Spinbox(g, from_=0, to=500, textvariable=self.margin_var, width=8))
        row(4, "Ripeti progetto x", ttk.Spinbox(g, from_=1, to=1000, textvariable=self.mult_var, width=8))
        row(5, "Mostra quantita' in", ttk.Combobox(g, values=UNIT_MODES, textvariable=self.unit_mode, state="readonly"))
        ttk.Checkbutton(t3, text="Blast furnace per minerali/metalli (meta' combustibile, meta' tempo)",
                        variable=self.blast_var).pack(anchor="w", pady=(8, 2))
        ttk.Checkbutton(t3, text="Stonecutter per scale, lastre, muretti, mattoni (piu' economico)",
                        variable=self.stone_var).pack(anchor="w", pady=2)
        ttk.Label(t3, text="Considera come materiale base (non craftare):", style="H2.TLabel").pack(anchor="w", pady=(14, 4))
        self.raw_list = ItemList(t3, self, False, self.schedule_calc, height=5)
        self.raw_list.pack(fill="both", expand=True)

        ttk.Button(left, text="CALCOLA   (Ctrl+Invio)", style="Big.Accent.TButton",
                   command=self.calculate).pack(fill="x", pady=(10, 0))

    def _card(self, parent, key, title):
        f = ttk.Frame(parent, style="Card.TFrame", padding=(14, 10))
        ttk.Label(f, text=title, style="CardTitle.TLabel").pack(anchor="w")
        v, s = tk.StringVar(value="-"), tk.StringVar(value="")
        ttk.Label(f, textvariable=v, style="CardValue.TLabel").pack(anchor="w")
        ttk.Label(f, textvariable=s, style="CardSub.TLabel").pack(anchor="w")
        self.card_vars[key] = (v, s)
        return f

    def _make_tree(self, parent, cols, heads, widths, anchors=None, height=12, show="headings"):
        wrap = ttk.Frame(parent)
        tv = ttk.Treeview(wrap, columns=cols, show=show, height=height)
        for i, c in enumerate(cols):
            tv.heading(c, text=heads[i], anchor=(anchors or {}).get(c, "w"))
            tv.column(c, width=widths[i], anchor=(anchors or {}).get(c, "w"), stretch=(i == len(cols) - 1))
        ys = ttk.Scrollbar(wrap, orient="vertical", command=tv.yview)
        xs = ttk.Scrollbar(wrap, orient="horizontal", command=tv.xview)
        tv.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        ys.pack(side="right", fill="y")
        xs.pack(side="bottom", fill="x")
        tv.pack(side="left", fill="both", expand=True)
        self.trees.append(tv)
        return wrap, tv

    def _build_right(self, right):
        cards = ttk.Frame(right)
        cards.pack(fill="x")
        for i, (k, t) in enumerate([("types", "MATERIALI BASE"), ("stacks", "DA RACCOGLIERE"),
                                     ("crafts", "CRAFT"), ("smelt", "SMELT"), ("fuel", "COMBUSTIBILE")]):
            self._card(cards, k, t).grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0))
            cards.columnconfigure(i, weight=1, uniform="c")

        self.tabs = ttk.Notebook(right)
        self.tabs.pack(fill="both", expand=True, pady=(10, 0))

        # Riepilogo
        t = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(t, text="Riepilogo")
        self.chart = tk.Canvas(t, highlightthickness=0)
        self.chart.pack(fill="both", expand=True)
        self.chart.bind("<Configure>", lambda e: self.draw_chart())

        # Materiali base (tracker)
        t = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(t, text="Materiali base")
        bar = ttk.Frame(t)
        bar.pack(fill="x", pady=(0, 8))
        self.prog = ttk.Progressbar(bar, maximum=100, length=260)
        self.prog.pack(side="left")
        self.prog_lbl = ttk.Label(bar, text="0%", style="Muted.TLabel")
        self.prog_lbl.pack(side="left", padx=8)
        ttk.Button(bar, text="Azzera raccolti", command=self.reset_collected).pack(side="right")
        ttk.Button(bar, text="Segna tutto raccolto", command=self.all_collected).pack(side="right", padx=6)
        ttk.Label(bar, text="doppio clic su una riga = quanti ne hai raccolti", style="Muted.TLabel").pack(side="right", padx=10)
        w, self.raw_tv = self._make_tree(
            t, ("item", "need", "stk", "inv", "got", "miss", "pct"),
            ["Materiale", "Servono", "Stack", "Da inventario", "Raccolti", "Mancano", "%"],
            [230, 100, 110, 110, 100, 100, 60],
            {"need": "e", "stk": "e", "inv": "e", "got": "e", "miss": "e", "pct": "e"}, height=16)
        w.pack(fill="both", expand=True)
        self.raw_tv.bind("<Double-1>", self._edit_collected)

        # Passaggi
        t = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(t, text="Passaggi")
        ttk.Label(t, text="Doppio clic su un passaggio = segnalo come fatto", style="Muted.TLabel").pack(anchor="w", pady=(0, 8))
        w, self.steps_tv = self._make_tree(
            t, ("done", "n", "type", "item", "made", "uses", "extra"),
            ["", "#", "Tipo", "Oggetto", "Risultato", "Ingredienti", "Avanzo"],
            [34, 40, 70, 200, 220, 420, 90], {"n": "e", "extra": "e"}, height=16)
        w.pack(fill="both", expand=True)
        self.steps_tv.bind("<Double-1>", self._toggle_step)

        # Combustibile
        t = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(t, text="Combustibile")
        self.fuel_info = ttk.Label(t, text="", style="H2.TLabel", justify="left")
        self.fuel_info.pack(anchor="w", pady=(0, 8))
        w, self.fuel_tv = self._make_tree(
            t, ("fuel", "qty", "disp"), ["Combustibile (ne basta uno)", "Quantita'", "Dettaglio"],
            [260, 120, 360], {"qty": "e"}, height=12)
        w.pack(fill="both", expand=True)

        # Albero
        t = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(t, text="Albero ricette")
        bar = ttk.Frame(t)
        bar.pack(fill="x", pady=(0, 8))
        ttk.Button(bar, text="Espandi tutto", command=lambda: self._set_open("", True)).pack(side="left")
        ttk.Button(bar, text="Comprimi", command=lambda: self._set_open("", False)).pack(side="left", padx=6)
        ttk.Label(bar, text="quantita' per ramo (i totali esatti sono nelle altre schede)",
                  style="Muted.TLabel").pack(side="left", padx=10)
        w, self.tree_tv = self._make_tree(
            t, ("qty", "kind"), ["Oggetto", "Quantita'", "Tipo"], [380, 130, 160],
            {"qty": "e"}, height=16, show="tree headings")
        self.tree_tv.heading("#0", text="Oggetto", anchor="w")
        self.tree_tv.column("#0", width=380, anchor="w", stretch=True)
        w.pack(fill="both", expand=True)

        # Report testuale
        t = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(t, text="Report")
        bar = ttk.Frame(t)
        bar.pack(fill="x", pady=(0, 8))
        ttk.Button(bar, text="Copia", command=self.copy_text).pack(side="left")
        ttk.Button(bar, text="Salva TXT...", command=self.save_text).pack(side="left", padx=6)
        ttk.Button(bar, text="Esporta CSV...", command=self.export_csv).pack(side="left")
        wrap = ttk.Frame(t)
        wrap.pack(fill="both", expand=True)
        self.text = tk.Text(wrap, wrap="none", font=(MONO, 10), relief="flat", borderwidth=0, padx=10, pady=8)
        ys = ttk.Scrollbar(wrap, orient="vertical", command=self.text.yview)
        xs = ttk.Scrollbar(wrap, orient="horizontal", command=self.text.xview)
        self.text.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        ys.pack(side="right", fill="y")
        xs.pack(side="bottom", fill="x")
        self.text.pack(side="left", fill="both", expand=True)

    # ------------------------------------------------------------ tema
    def toggle_theme(self):
        self.theme_var.set("Chiaro" if self.theme_var.get() == "Scuro" else "Scuro")
        self.apply_theme(self.theme_var.get())

    def apply_theme(self, name):
        self.pal = p = PALETTES[name]
        s = self.style
        s.theme_use("clam")
        self.configure(bg=p["bg"])
        s.configure(".", background=p["bg"], foreground=p["fg"], fieldbackground=p["entry"],
                    bordercolor=p["border"], lightcolor=p["bg"], darkcolor=p["bg"],
                    troughcolor=p["panel"], focuscolor=p["accent"], font=(FONT, 10))
        s.configure("TFrame", background=p["bg"])
        s.configure("Panel.TFrame", background=p["panel"])
        s.configure("Card.TFrame", background=p["card"])
        s.configure("TLabel", background=p["bg"], foreground=p["fg"])
        s.configure("Muted.TLabel", foreground=p["muted"])
        s.configure("H2.TLabel", font=(FONT, 11, "bold"), foreground=p["fg"])
        s.configure("Header.TLabel", background=p["panel"], font=(FONT, 13, "bold"), foreground=p["accent"])
        s.configure("HeaderMuted.TLabel", background=p["panel"], foreground=p["muted"])
        s.configure("CardTitle.TLabel", background=p["card"], foreground=p["muted"], font=(FONT, 8, "bold"))
        s.configure("CardValue.TLabel", background=p["card"], foreground=p["accent"], font=(FONT, 20, "bold"))
        s.configure("CardSub.TLabel", background=p["card"], foreground=p["muted"], font=(FONT, 9))
        s.configure("TButton", background=p["card"], foreground=p["fg"], bordercolor=p["border"],
                    padding=(10, 5), relief="flat")
        s.map("TButton", background=[("active", p["border"])])
        s.configure("Accent.TButton", background=p["accent"], foreground=p["on_accent"],
                    font=(FONT, 10, "bold"), padding=(12, 5), bordercolor=p["accent"])
        s.map("Accent.TButton", background=[("active", p["accent_h"])])
        s.configure("Big.Accent.TButton", font=(FONT, 12, "bold"), padding=(14, 11))
        s.configure("TCheckbutton", background=p["bg"], foreground=p["fg"])
        s.configure("Header.TCheckbutton", background=p["panel"])
        s.map("TCheckbutton", background=[("active", p["bg"])],
              indicatorcolor=[("selected", p["accent"]), ("!selected", p["entry"])])
        s.map("Header.TCheckbutton", background=[("active", p["panel"])])
        s.configure("TEntry", fieldbackground=p["entry"], foreground=p["fg"], insertcolor=p["fg"])
        for w in ("TCombobox", "TSpinbox"):
            s.configure(w, fieldbackground=p["entry"], background=p["card"], foreground=p["fg"],
                        arrowcolor=p["fg"], insertcolor=p["fg"], bordercolor=p["border"])
        s.map("TCombobox", fieldbackground=[("readonly", p["entry"])], foreground=[("readonly", p["fg"])],
              selectbackground=[("readonly", p["entry"])], selectforeground=[("readonly", p["fg"])])
        self.option_add("*TCombobox*Listbox.background", p["entry"])
        self.option_add("*TCombobox*Listbox.foreground", p["fg"])
        self.option_add("*TCombobox*Listbox.selectBackground", p["sel"])
        self.option_add("*TCombobox*Listbox.selectForeground", p["fg"])
        s.configure("TNotebook", background=p["bg"], borderwidth=0, tabmargins=(0, 4, 0, 0))
        s.configure("TNotebook.Tab", background=p["panel"], foreground=p["muted"], padding=(14, 8), borderwidth=0)
        s.map("TNotebook.Tab", background=[("selected", p["card"])], foreground=[("selected", p["accent"])])
        s.configure("TLabelframe", background=p["bg"], bordercolor=p["border"])
        s.configure("TLabelframe.Label", background=p["bg"], foreground=p["accent"], font=(FONT, 10, "bold"))
        s.configure("Horizontal.TProgressbar", background=p["accent"], troughcolor=p["panel"],
                    bordercolor=p["border"], lightcolor=p["accent"], darkcolor=p["accent"])
        for o in ("Vertical", "Horizontal"):
            s.configure(f"{o}.TScrollbar", background=p["card"], troughcolor=p["panel"],
                        arrowcolor=p["muted"], bordercolor=p["panel"])
        s.configure("Treeview", background=p["card"], fieldbackground=p["card"], foreground=p["fg"],
                    rowheight=27, borderwidth=0, relief="flat")
        s.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])
        s.map("Treeview", background=[("selected", p["sel"])], foreground=[("selected", p["fg"])])
        s.configure("Treeview.Heading", background=p["panel"], foreground=p["muted"], relief="flat",
                    font=(FONT, 9, "bold"), padding=(6, 6))
        s.map("Treeview.Heading", background=[("active", p["border"])])
        s.configure("TPanedwindow", background=p["bg"])

        for tv in self.trees:
            tv.tag_configure("odd", background=p["row2"])
            tv.tag_configure("even", background=p["card"])
            tv.tag_configure("done", foreground=p["accent"])
            tv.tag_configure("craft", foreground=p["accent2"])
            tv.tag_configure("smelt", foreground=p["amber"])
            tv.tag_configure("raw", foreground=p["fg"])
            tv.tag_configure("selfuel", foreground=p["accent"])
        self.text.configure(bg=p["entry"], fg=p["fg"], insertbackground=p["fg"], selectbackground=p["sel"])
        self.text.tag_configure("head", foreground=p["accent"], font=(MONO, 11, "bold"))
        self.text.tag_configure("sep", foreground=p["border"])
        self.text.tag_configure("warn", foreground=p["warn"])
        self.chart.configure(bg=p["card"])
        self.logo.configure(bg=p["panel"])
        self.logo.delete("all")
        for i in range(3):          # piccolo logo a blocchi
            for j in range(3):
                shade = p["accent"] if (i + j) % 2 == 0 else p["accent_h"]
                self.logo.create_rectangle(2 + i * 8, 2 + j * 8, 9 + i * 8, 9 + j * 8, fill=shade, outline="")
        self.render_all()

    def color_for(self, name):
        h = (zlib.crc32(name.encode()) % 360) / 360.0
        light = 0.58 if self.pal["dark"] else 0.42
        r, g, b = colorsys.hls_to_rgb(h, light, 0.55)
        return "#%02x%02x%02x" % (int(r * 255), int(g * 255), int(b * 255))

    # ------------------------------------------------------------ calcolo
    def disp(self, n, item):
        mode, ss = self.unit_mode.get(), mc.stack_size(item)
        if mode == "Solo pezzi":
            return mc.fmt(n)
        if mode == "Shulker box":
            return f"{mc.fmt(n)}  ({n / (27 * ss):.2f} shulker)"
        if mode == "Double chest":
            return f"{mc.fmt(n)}  ({n / (54 * ss):.2f} double chest)"
        return mc.with_stacks(n, item)

    def schedule_calc(self, *_):
        if self._loading:
            return
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(250, self._auto)

    def _auto(self):
        self._job = None
        if self.auto_var.get():
            self.calculate(silent=True)

    def calculate(self, silent=False):
        if not self.targets_list.data:
            self.plan = None
            self.render_all()
            if not silent:
                messagebox.showinfo("Niente da calcolare", "Aggiungi almeno un oggetto al progetto.")
            return
        try:
            self.plan = mc.plan(
                dict(self.targets_list.data), wood=self.wood_var.get(), have=dict(self.have_list.data),
                treat_raw=list(self.raw_list.data), stonecutter=self.stone_var.get(),
                blast=self.blast_var.get(), mult=int_of(self.mult_var, 1, 1, 1000),
                margin=int_of(self.margin_var, 0, 0, 500), furnaces=int_of(self.furn_var, 1, 1, 200),
                fuel=self.fuel_var.get())
        except Exception as e:
            self.plan = None
            self.render_all()
            messagebox.showerror("Errore nel calcolo", str(e))
            return
        self.render_all()
        msg = f"Calcolo aggiornato: {len(self.plan['steps'])} passaggi, {len(self.plan['raw'])} materiali base."
        if self.plan["unknown"]:
            msg += "  [!] Senza ricetta (trattati come base): " + ", ".join(mc.pretty(u) for u in self.plan["unknown"])
        self.status.set(msg)

    # ------------------------------------------------------------ render
    def render_all(self):
        self.render_cards()
        self.draw_chart()
        self.render_raw()
        self.render_steps()
        self.render_fuel()
        self.render_tree()
        self.render_text()

    def render_cards(self):
        p = self.plan
        if not p:
            for v, s in self.card_vars.values():
                v.set("-")
                s.set("")
            return
        stacks = sum(math.ceil(n / mc.stack_size(i)) for i, n in p["raw"].items())
        crafts = sum(r for i, r in p["runs"].items() if p["recipes"][i][2] == "craft")
        sm = p["smelt"] + p["ore"]
        self.card_vars["types"][0].set(str(len(p["raw"])))
        self.card_vars["types"][1].set(f"{len(p['steps'])} passaggi")
        self.card_vars["stacks"][0].set(f"{mc.fmt(stacks)} st")
        self.card_vars["stacks"][1].set(f"{mc.fmt(sum(p['raw'].values()))} pezzi")
        self.card_vars["crafts"][0].set(mc.fmt(crafts))
        self.card_vars["crafts"][1].set("operazioni di crafting")
        self.card_vars["smelt"][0].set(mc.fmt(sm))
        self.card_vars["smelt"][1].set(f"~{mc.fmt_time(p['seconds'])} con {p['furnaces']} fornaci" if sm else "nessuna fusione")
        self.card_vars["fuel"][0].set(mc.fmt(p["fuels"].get(p["fuel"], 0)))
        self.card_vars["fuel"][1].set(mc.pretty(p["fuel"]) if sm else "non serve")

    def draw_chart(self):
        c, p = self.chart, self.plan
        c.delete("all")
        w, h = max(c.winfo_width(), 400), max(c.winfo_height(), 200)
        pal = self.pal
        if not p or not p["raw"]:
            c.create_text(w / 2, h / 2, fill=pal["muted"], font=(FONT, 12),
                          text="Aggiungi gli oggetti a sinistra: il grafico dei materiali apparira' qui."
                          if not p else "Hai gia' tutto nell'inventario!")
            return
        items = sorted(p["raw"].items(), key=lambda x: -x[1] / mc.stack_size(x[0]))[:14]
        mx = max(n / mc.stack_size(i) for i, n in items) or 1
        c.create_text(16, 18, anchor="w", fill=pal["fg"], font=(FONT, 12, "bold"),
                      text="Materiali piu' pesanti (in stack)")
        x0, x1, y = 190, w - 230, 44
        for item, n in items:
            st = n / mc.stack_size(item)
            c.create_text(x0 - 10, y + 11, anchor="e", fill=pal["fg"], font=(FONT, 10), text=mc.pretty(item))
            c.create_rectangle(x0, y, x1, y + 22, fill=pal["row2"], outline="")
            c.create_rectangle(x0, y, x0 + max(3, (x1 - x0) * st / mx), y + 22, fill=self.color_for(item), outline="")
            txt = mc.fmt(n) if mc.stack_size(item) == 1 else f"{mc.fmt(n)}  ·  {st:.1f} st"
            c.create_text(x1 + 10, y + 11, anchor="w", fill=pal["muted"], font=(FONT, 10), text=txt)
            y += 29

    def render_raw(self):
        tv, p = self.raw_tv, self.plan
        tv.delete(*tv.get_children())
        tot = got_tot = 0.0
        if p:
            for i, (item, n) in enumerate(sorted(p["raw"].items(), key=lambda x: mc.pretty(x[0]))):
                got = self.collected.get(item, 0)
                ss = mc.stack_size(item)
                pct = 100 if n == 0 else min(100, got * 100 // n)
                tot += n / ss
                got_tot += min(got, n) / ss
                inv = mc.fmt(p["used"][item]) if item in p["used"] else "-"
                tags = ["odd" if i % 2 else "even"] + (["done"] if got >= n else [])
                tv.insert("", "end", iid=item, tags=tuple(tags), values=(
                    mc.pretty(item), mc.fmt(n), stk(n, item), inv, mc.fmt(got), mc.fmt(max(0, n - got)), f"{pct}%"))
        pct_all = 100 * got_tot / tot if tot else 0
        self.prog["value"] = pct_all
        self.prog_lbl.configure(text=f"{pct_all:.0f}% raccolto")

    def render_steps(self):
        tv, p = self.steps_tv, self.plan
        tv.delete(*tv.get_children())
        if not p:
            return
        for k, item in enumerate(p["steps"], 1):
            out, ing, kind = p["recipes"][item]
            r = p["runs"][item]
            made = r * out
            uses = "  +  ".join(f"{mc.fmt(r * q)} {mc.pretty(i)}" for i, q in ing.items())
            res = f"{mc.fmt(r)} craft -> {mc.fmt(made)}" if kind == "craft" else f"{mc.fmt(made)} da smeltare"
            extra = mc.fmt(made - p["need"][item]) if made > p["need"][item] else ""
            done = item in self.done_steps
            tv.insert("", "end", iid=item, tags=("odd" if k % 2 else "even", "done" if done else ("craft" if kind == "craft" else "smelt")),
                      values=("✓" if done else "", k, "CRAFT" if kind == "craft" else "SMELT",
                              mc.pretty(item), res, uses, extra))

    def render_fuel(self):
        tv, p = self.fuel_tv, self.plan
        tv.delete(*tv.get_children())
        if not p:
            self.fuel_info.configure(text="")
            return
        sm = p["smelt"] + p["ore"]
        if not sm:
            self.fuel_info.configure(text="Niente da smeltare: nessun combustibile necessario.")
            return
        self.fuel_info.configure(text=(
            f"{mc.fmt(sm)} oggetti da smeltare  ·  {p['furnaces']} fornaci  ·  tempo stimato {mc.fmt_time(p['seconds'])}"
            + (f"\n{mc.fmt(p['ore'])} minerali/metalli in blast furnace (meta' combustibile)" if p["blast"] and p["ore"] else "")))
        names = {"planks": "Planks (qualsiasi)", "log": "Log (qualsiasi)"}
        for i, (f, q) in enumerate(p["fuels"].items()):
            label = names.get(f, mc.pretty(f))
            if f == "charcoal":
                label += f"  (servono {mc.fmt(q)} log da cuocere)"
            tv.insert("", "end", iid=f, tags=("odd" if i % 2 else "even", "selfuel" if f == p["fuel"] else "raw"),
                      values=(label + ("   <-- scelto" if f == p["fuel"] else ""), mc.fmt(q), self.disp(q, f)))

    def render_tree(self):
        tv = self.tree_tv
        tv.delete(*tv.get_children())
        if not self.plan:
            return

        def add(parent, nd, depth):
            kind = {"craft": "craft", "smelt": "smelt", "ore": "smelt", "raw": "raw"}[nd["kind"]]
            label = {"craft": f"craft x{mc.fmt(nd['runs'])}", "smelt": "smelt", "raw": "materiale base"}[kind]
            iid = tv.insert(parent, "end", text=mc.pretty(nd["item"]), open=depth < 1,
                            values=(mc.fmt(nd["qty"]), label), tags=(kind,))
            for ch in nd["children"]:
                add(iid, ch, depth + 1)

        for nd in mc.plan_tree(self.plan):
            add("", nd, 0)

    def _set_open(self, parent, flag):
        for iid in self.tree_tv.get_children(parent):
            self.tree_tv.item(iid, open=flag)
            self._set_open(iid, flag)

    def render_text(self):
        self.text.delete("1.0", "end")
        if not self.plan:
            self.text.insert("end", "Nessun calcolo ancora.")
            return
        prev = ""
        for line in mc.plan_text(self.plan, self.disp).splitlines():
            if line.startswith("="):
                tag = "sep"
            elif prev.startswith("=") and line.startswith(" "):
                tag = "head"
            elif "[!]" in line:
                tag = "warn"
            else:
                tag = None
            self.text.insert("end", line + "\n", tag)
            prev = line

    # ------------------------------------------------------------ tracker
    def _edit_collected(self, event):
        iid = self.raw_tv.identify_row(event.y)
        if not iid or not self.plan:
            return
        v = simpledialog.askinteger("Raccolti", f"Quanti {mc.pretty(iid)} hai raccolto?",
                                    initialvalue=self.collected.get(iid, 0), minvalue=0,
                                    maxvalue=10 ** 9, parent=self)
        if v is not None:
            self.collected[iid] = v
            self.render_raw()

    def all_collected(self):
        if self.plan:
            self.collected.update(self.plan["raw"])
            self.render_raw()

    def reset_collected(self):
        self.collected.clear()
        self.render_raw()

    def _toggle_step(self, event):
        iid = self.steps_tv.identify_row(event.y)
        if iid:
            self.done_steps ^= {iid}
            self.render_steps()

    # ------------------------------------------------------------ file
    def import_file(self):
        path = filedialog.askopenfilename(
            title="Material list di Litematica",
            filetypes=[("Material list", "*.csv *.txt"), ("Tutti i file", "*.*")])
        if not path:
            return
        try:
            loaded = mc.load_file(path, self.missing_var.get())
        except Exception as e:
            messagebox.showerror("Errore", f"Impossibile leggere il file:\n{e}")
            return
        if not loaded:
            messagebox.showwarning("Nessun oggetto", "Non ho trovato oggetti nel file (o tutte le quantita' erano 0).")
            return
        self.targets_list.merge(loaded)
        self.status.set(f"Importati {len(loaded)} tipi di oggetto da {os.path.basename(path)}.")

    def get_state(self):
        return {"targets": self.targets_list.data, "have": self.have_list.data,
                "treat_raw": list(self.raw_list.data), "collected": self.collected,
                "done_steps": sorted(self.done_steps),
                "opts": {"wood": self.wood_var.get(), "fuel": self.fuel_var.get(),
                         "blast": self.blast_var.get(), "stonecutter": self.stone_var.get(),
                         "furnaces": int_of(self.furn_var, 1), "margin": int_of(self.margin_var, 0),
                         "mult": int_of(self.mult_var, 1), "unit_mode": self.unit_mode.get(),
                         "auto": self.auto_var.get(), "missing": self.missing_var.get(),
                         "theme": self.theme_var.get()}}

    def set_state(self, s):
        self._loading = True
        try:
            self.targets_list.set_data(s.get("targets", {}))
            self.have_list.set_data(s.get("have", {}))
            self.raw_list.set_data({k: 1 for k in s.get("treat_raw", [])})
            self.collected = dict(s.get("collected", {}))
            self.done_steps = set(s.get("done_steps", []))
            o = s.get("opts", {})
            self.wood_var.set(o.get("wood", "oak"))
            self.fuel_var.set(o.get("fuel", "coal"))
            self.blast_var.set(o.get("blast", False))
            self.stone_var.set(o.get("stonecutter", False))
            self.furn_var.set(o.get("furnaces", 1))
            self.margin_var.set(o.get("margin", 0))
            self.mult_var.set(o.get("mult", 1))
            self.unit_mode.set(o.get("unit_mode", UNIT_MODES[0]))
            self.auto_var.set(o.get("auto", True))
            self.missing_var.set(o.get("missing", False))
            if o.get("theme") in PALETTES and o["theme"] != self.theme_var.get():
                self.theme_var.set(o["theme"])
                self.apply_theme(o["theme"])
        finally:
            self._loading = False
        self.calculate(silent=True)

    def new_project(self):
        if self.targets_list.data and not messagebox.askyesno("Nuovo progetto", "Cancellare il progetto attuale?"):
            return
        self.project_path = None
        self.set_state({})
        self.status.set("Nuovo progetto.")

    def save_project(self, as_new=False):
        path = self.project_path
        if as_new or not path:
            path = filedialog.asksaveasfilename(defaultextension=".mcproj", initialfile="progetto.mcproj",
                                                filetypes=[("Progetto calcolatore", "*.mcproj"), ("JSON", "*.json")])
        if not path:
            return
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.get_state(), f, ensure_ascii=False, indent=2)
        self.project_path = path
        self.status.set(f"Progetto salvato: {path}")

    def open_project(self):
        path = filedialog.askopenfilename(filetypes=[("Progetto calcolatore", "*.mcproj *.json"), ("Tutti i file", "*.*")])
        if not path:
            return
        try:
            with open(path, encoding="utf-8") as f:
                self.set_state(json.load(f))
        except Exception as e:
            messagebox.showerror("Errore", f"File non valido:\n{e}")
            return
        self.project_path = path
        self.status.set(f"Progetto aperto: {path}")

    def copy_text(self):
        self.clipboard_clear()
        self.clipboard_append(self.text.get("1.0", "end").strip())
        self.status.set("Report copiato negli appunti.")

    def save_text(self):
        if not self.plan:
            messagebox.showinfo("Niente da salvare", "Fai prima un calcolo.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".txt", initialfile="materiali.txt",
                                            filetypes=[("Testo", "*.txt")])
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(mc.plan_text(self.plan, self.disp))

    def export_csv(self):
        if not self.plan:
            messagebox.showinfo("Niente da esportare", "Fai prima un calcolo.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="materiali.csv",
                                            filetypes=[("CSV", "*.csv")])
        if not path:
            return
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["Materiale", "Servono", "Stack", "Da inventario", "Raccolti", "Mancano"])
            for item, n in sorted(self.plan["raw"].items(), key=lambda x: mc.pretty(x[0])):
                got = self.collected.get(item, 0)
                w.writerow([mc.pretty(item), n, stk(n, item), self.plan["used"].get(item, 0), got, max(0, n - got)])
        self.status.set(f"CSV esportato: {path}")

    def show_help(self):
        messagebox.showinfo("Guida rapida", (
            "1. Progetto: aggiungi gli oggetti (o importa la material list di Litematica).\n"
            "2. Inventario: cosa hai gia' nei chest, viene sottratto dal calcolo.\n"
            "3. Opzioni: legno, fornaci, blast furnace, stonecutter, margine, ripetizioni.\n\n"
            "Materiali base: doppio clic per segnare quanti ne hai raccolti.\n"
            "Passaggi: doppio clic per segnarli come fatti.\n"
            "Progetto: Ctrl+S salva, Ctrl+O apre (raccolti e passaggi inclusi).\n"
            "Ctrl+Invio / F5 = calcola."))


if __name__ == "__main__":
    try:
        App().mainloop()
    except Exception as exc:  # .pyw non ha console: mostra l'errore in una finestra
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Errore", str(exc))
