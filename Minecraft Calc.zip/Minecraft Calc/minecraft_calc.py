#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Calcolatore materiali Minecraft (Java) con supporto alla material list di Litematica.

Esempi:
    python minecraft_calc.py                                  (modalita' interattiva)
    python minecraft_calc.py chiseled_bookshelf=3000
    python minecraft_calc.py "chiseled bookshelf 3000" "glass 500" --wood spruce
    python minecraft_calc.py --file materiali.csv             (export di Litematica)
    python minecraft_calc.py --file materiali.csv --missing   (solo i blocchi che ti mancano)
    python minecraft_calc.py stone_bricks=2000 --blast        (fornace: usa blast furnace per i minerali)

Per aggiungere ricette: vai in build_recipes() e aggiungi una riga:
    craft("nome_output", quantita_prodotta, {"ingrediente": quantita, ...})
    smelt("nome_output", "ingrediente")            # fornace
    smelt("nome_output", "ingrediente", ore=True)  # minerali/metalli (ok anche blast furnace)
"""
import argparse
import csv
import math
import re
import sys
from collections import defaultdict

WOODS = ["oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove",
         "cherry", "pale_oak", "bamboo", "crimson", "warped"]

# Quanti oggetti smelta 1 unita' di combustibile (burn time / 200 tick)
FUELS = {
    "coal": 8, "charcoal": 8, "coal_block": 80, "blaze_rod": 12,
    "lava_bucket": 100, "dried_kelp_block": 20,
    "planks": 1.5, "log": 1.5, "stick": 0.5,
}

ALIASES = {
    "block_of_iron": "iron_block", "block_of_gold": "gold_block",
    "block_of_diamond": "diamond_block", "block_of_emerald": "emerald_block",
    "block_of_redstone": "redstone_block", "block_of_lapis_lazuli": "lapis_block",
    "block_of_coal": "coal_block", "block_of_copper": "copper_block",
    "block_of_quartz": "quartz_block", "redstone_dust": "redstone",
    "lapis": "lapis_lazuli", "stone_brick": "stone_bricks", "brick_block": "bricks",
}


def build_recipes(wood):
    """Ritorna {output: (quantita_prodotta, {ingrediente: qta}, tipo)} - tipo: craft | smelt | ore"""
    R = {}

    def craft(out, n, ing):
        R[out] = (n, ing, "craft")

    def smelt(out, src, ore=False):
        R[out] = (1, {src: 1}, "ore" if ore else "smelt")

    P, S = f"{wood}_planks", f"{wood}_slab"   # legno scelto per le ricette "qualsiasi planks"

    # ---------- Legno (tutti i tipi) ----------
    for w in WOODS:
        pl = f"{w}_planks"
        if w == "bamboo":
            craft(pl, 2, {"bamboo_block": 1})
        elif w in ("crimson", "warped"):
            craft(pl, 4, {f"{w}_stem": 1})
        else:
            craft(pl, 4, {f"{w}_log": 1})
        craft(f"{w}_slab", 6, {pl: 3})
        craft(f"{w}_stairs", 4, {pl: 6})
        craft(f"{w}_fence", 3, {pl: 4, "stick": 2})
        craft(f"{w}_fence_gate", 1, {pl: 2, "stick": 4})
        craft(f"{w}_door", 3, {pl: 6})
        craft(f"{w}_trapdoor", 2, {pl: 6})
        craft(f"{w}_button", 1, {pl: 1})
        craft(f"{w}_pressure_plate", 1, {pl: 2})
        craft(f"{w}_sign", 3, {pl: 6, "stick": 1})

    craft("stick", 4, {P: 2})
    craft("crafting_table", 1, {P: 4})
    craft("chest", 1, {P: 8})
    craft("barrel", 1, {P: 6, S: 2})
    craft("ladder", 3, {"stick": 7})
    craft("composter", 1, {S: 7})
    craft("chiseled_bookshelf", 1, {P: 6, S: 3})
    craft("paper", 3, {"sugar_cane": 3})
    craft("book", 1, {"paper": 3, "leather": 1})
    craft("bookshelf", 1, {P: 6, "book": 3})
    craft("lectern", 1, {S: 4, "bookshelf": 1})
    craft("torch", 4, {"coal": 1, "stick": 1})

    # ---------- Pietra e simili ----------
    smelt("stone", "cobblestone")
    smelt("smooth_stone", "stone")
    craft("stone_bricks", 4, {"stone": 4})
    smelt("cracked_stone_bricks", "stone_bricks")
    craft("stone_slab", 6, {"stone": 3})
    craft("stone_stairs", 4, {"stone": 6})
    craft("smooth_stone_slab", 6, {"smooth_stone": 3})
    craft("stone_brick_slab", 6, {"stone_bricks": 3})
    craft("stone_brick_stairs", 4, {"stone_bricks": 6})
    craft("stone_brick_wall", 6, {"stone_bricks": 6})
    craft("chiseled_stone_bricks", 1, {"stone_brick_slab": 2})
    craft("cobblestone_slab", 6, {"cobblestone": 3})
    craft("cobblestone_stairs", 4, {"cobblestone": 6})
    craft("cobblestone_wall", 6, {"cobblestone": 6})
    for k in ("andesite", "diorite", "granite"):
        craft(f"polished_{k}", 4, {k: 4})
    craft("stone_button", 1, {"stone": 1})
    craft("stone_pressure_plate", 1, {"stone": 2})

    # Deepslate / Blackstone
    smelt("deepslate", "cobbled_deepslate")
    craft("polished_deepslate", 4, {"cobbled_deepslate": 4})
    craft("deepslate_bricks", 4, {"polished_deepslate": 4})
    craft("deepslate_tiles", 4, {"deepslate_bricks": 4})
    smelt("cracked_deepslate_bricks", "deepslate_bricks")
    smelt("cracked_deepslate_tiles", "deepslate_tiles")
    craft("polished_blackstone", 4, {"blackstone": 4})
    craft("polished_blackstone_bricks", 4, {"polished_blackstone": 4})
    smelt("cracked_polished_blackstone_bricks", "polished_blackstone_bricks")

    # Nether
    smelt("nether_brick", "netherrack")
    craft("nether_bricks", 1, {"nether_brick": 4})
    craft("red_nether_bricks", 1, {"nether_brick": 2, "nether_wart": 2})
    smelt("cracked_nether_bricks", "nether_bricks")
    craft("nether_brick_slab", 6, {"nether_bricks": 3})
    craft("nether_brick_stairs", 4, {"nether_bricks": 6})
    craft("nether_brick_fence", 6, {"nether_bricks": 4, "nether_brick": 2})
    craft("chiseled_nether_bricks", 1, {"nether_brick_slab": 2})

    # Vetro, argilla, sabbia
    smelt("glass", "sand")
    craft("glass_pane", 16, {"glass": 6})
    smelt("brick", "clay_ball")
    craft("bricks", 1, {"brick": 4})
    craft("brick_slab", 6, {"bricks": 3})
    craft("brick_stairs", 4, {"bricks": 6})
    craft("clay", 1, {"clay_ball": 4})
    smelt("terracotta", "clay")
    craft("sandstone", 1, {"sand": 4})
    craft("sandstone_slab", 6, {"sandstone": 3})
    craft("cut_sandstone", 4, {"sandstone": 4})
    smelt("smooth_sandstone", "sandstone")
    craft("chiseled_sandstone", 1, {"sandstone_slab": 2})

    # Quarzo
    craft("quartz_block", 1, {"quartz": 4})
    craft("quartz_pillar", 2, {"quartz_block": 2})
    craft("quartz_slab", 6, {"quartz_block": 3})
    craft("quartz_bricks", 4, {"quartz_block": 4})
    craft("chiseled_quartz_block", 1, {"quartz_slab": 2})
    smelt("smooth_quartz", "quartz_block")

    # ---------- Metalli e blocchi di minerali ----------
    smelt("iron_ingot", "raw_iron", ore=True)
    smelt("gold_ingot", "raw_gold", ore=True)
    smelt("copper_ingot", "raw_copper", ore=True)
    for blk, item in (("iron_block", "iron_ingot"), ("gold_block", "gold_ingot"),
                      ("copper_block", "copper_ingot"), ("diamond_block", "diamond"),
                      ("emerald_block", "emerald"), ("lapis_block", "lapis_lazuli"),
                      ("redstone_block", "redstone"), ("coal_block", "coal")):
        craft(blk, 1, {item: 9})
    craft("cut_copper", 4, {"copper_block": 4})
    craft("iron_nugget", 9, {"iron_ingot": 1})
    craft("iron_bars", 16, {"iron_ingot": 6})
    craft("bucket", 1, {"iron_ingot": 3})
    craft("lantern", 1, {"iron_nugget": 8, "torch": 1})

    # ---------- Redstone ----------
    craft("redstone_torch", 1, {"redstone": 1, "stick": 1})
    craft("lever", 1, {"stick": 1, "cobblestone": 1})
    craft("repeater", 1, {"redstone_torch": 2, "redstone": 1, "stone": 3})
    craft("comparator", 1, {"redstone_torch": 3, "quartz": 1, "stone": 3})
    craft("piston", 1, {P: 3, "cobblestone": 4, "iron_ingot": 1, "redstone": 1})
    craft("sticky_piston", 1, {"piston": 1, "slime_ball": 1})
    craft("observer", 1, {"cobblestone": 6, "redstone": 2, "quartz": 1})
    craft("dropper", 1, {"cobblestone": 7, "redstone": 1})
    craft("bow", 1, {"stick": 3, "string": 3})
    craft("dispenser", 1, {"cobblestone": 7, "redstone": 1, "bow": 1})
    craft("hopper", 1, {"iron_ingot": 5, "chest": 1})
    craft("rail", 16, {"iron_ingot": 6, "stick": 1})
    craft("glowstone", 1, {"glowstone_dust": 4})
    craft("daylight_detector", 1, {"glass": 3, "quartz": 3, S: 3})

    # ---------- Varie ----------
    craft("hay_block", 1, {"wheat": 9})
    craft("white_wool", 1, {"string": 4})
    craft("white_carpet", 3, {"white_wool": 2})
    return R


# ---------------------------------------------------------------- utilita'

def normalize(name):
    n = name.strip().lower().replace("'", "").replace("-", "_")
    n = re.sub(r"[^a-z0-9_ ]", "", n)
    n = re.sub(r"\s+", "_", n).strip("_")
    return ALIASES.get(n, n)


def pretty(item):
    return item.replace("_", " ").title()


def fmt(n):
    return f"{int(n):,}".replace(",", ".")


def stack_size(item):
    if item == "lava_bucket":
        return 1
    if item in ("bucket", "honey_bottle", "ender_pearl") or item.endswith("_sign"):
        return 16
    return 64


def with_stacks(n, item):
    ss = stack_size(item)
    if ss == 1 or n < ss:
        return fmt(n)
    s, r = divmod(n, ss)
    txt = f"{fmt(n)}  ({fmt(s)} stack" + (f" + {r}" if r else "") + ")"
    if s >= 27:
        txt += f"  ~ {s / 27:.1f} shulker box"
    return txt


def parse_target(s):
    m = re.match(r"^\s*(\d+)\s*x?\s+(.+?)\s*$", s)
    if m:
        return normalize(m.group(2)), int(m.group(1))
    m = re.match(r"^\s*(.+?)\s*[=: ]\s*(\d+)\s*$", s)
    if m:
        return normalize(m.group(1)), int(m.group(2))
    return None


def load_file(path, use_missing):
    """Legge la material list di Litematica (CSV o tabella testuale con |)."""
    targets = defaultdict(int)
    idx = 2 if use_missing else 1
    with open(path, encoding="utf-8-sig", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line or set(line) <= set("+-=| "):
                continue
            if "|" in line:
                cells = [c.strip() for c in line.strip("|").split("|")]
            elif "," in line:
                cells = [c.strip() for c in next(csv.reader([line]))]
            else:
                continue
            low = [c.lower() for c in cells]
            if low and low[0] in ("item", "name"):
                for i, c in enumerate(low):
                    if use_missing and c.startswith("missing"):
                        idx = i
                    elif not use_missing and c.startswith("total"):
                        idx = i
                continue
            if len(cells) <= idx:
                continue
            m = re.search(r"\d+", cells[idx])
            if m and int(m.group()) > 0:
                targets[normalize(cells[0])] += int(m.group())
    return targets


# ---------------------------------------------------------------- calcolo

def compute(targets, recipes):
    need = defaultdict(int)
    for item, n in targets.items():
        need[item] += n

    visited, post = set(), []

    def dfs(x):
        if x in visited:
            return
        visited.add(x)
        if x in recipes:
            for ing in recipes[x][1]:
                dfs(ing)
        post.append(x)

    for t in targets:
        dfs(t)

    order = list(reversed(post))          # prima i "genitori", poi gli ingredienti
    runs = {}
    for item in order:
        if item in recipes:
            out, ing, _ = recipes[item]
            runs[item] = math.ceil(need[item] / out)
            for i, q in ing.items():
                need[i] += runs[item] * q
    raw = {i: need[i] for i in order if i not in recipes}
    steps = [i for i in reversed(order) if i in recipes]   # ordine di costruzione
    return need, runs, raw, steps


def report(targets, recipes, blast):
    need, runs, raw, steps = compute(targets, recipes)

    # materiali base noti (compaiono come ingredienti ma non hanno ricetta)
    known_raw = {i for (_, ing, _) in recipes.values() for i in ing if i not in recipes}
    unknown = [t for t in targets if t not in recipes and t not in known_raw]

    line = "=" * 64
    print(f"\n{line}\n OBIETTIVO\n{line}")
    for t, n in targets.items():
        print(f"  {pretty(t)}: {with_stacks(n, t)}")
    if unknown:
        print("\n  [!] Nessuna ricetta nel database per: "
              + ", ".join(pretty(u) for u in unknown)
              + "\n      li tratto come materiali base (puoi aggiungere la ricetta in build_recipes()).")

    print(f"\n{line}\n MATERIALI BASE DA RACCOGLIERE\n{line}")
    for item, n in sorted(raw.items(), key=lambda x: x[0]):
        print(f"  {pretty(item):<28} {with_stacks(n, item)}")

    print(f"\n{line}\n PASSAGGI (in ordine: parti dall'alto)\n{line}")
    smelt_items = ore_items = 0
    for k, item in enumerate(steps, 1):
        out, ing, kind = recipes[item]
        r = runs[item]
        produced = r * out
        ing_txt = " + ".join(f"{fmt(r * q)} {pretty(i)}" for i, q in ing.items())
        extra = f"   (avanzo {fmt(produced - need[item])})" if produced > need[item] else ""
        if kind == "craft":
            print(f"{k:>3}. CRAFT {pretty(item)}: {fmt(r)} craft -> {fmt(produced)} pezzi{extra}")
        else:
            print(f"{k:>3}. SMELT {pretty(item)}: {fmt(produced)} pezzi{extra}")
            if kind == "ore":
                ore_items += produced
            else:
                smelt_items += produced
        print(f"       usa: {ing_txt}")

    effective = smelt_items + ore_items * (0.5 if blast else 1)
    total_smelt = smelt_items + ore_items
    if total_smelt:
        print(f"\n{line}\n COMBUSTIBILE PER LE SMELT\n{line}")
        print(f"  Oggetti da smeltare: {fmt(total_smelt)}"
              + (f"  (di cui {fmt(ore_items)} in blast furnace: meta' combustibile)" if blast and ore_items else ""))
        print("  Una sola di queste opzioni basta:")
        for fuel, per in FUELS.items():
            qty = math.ceil(effective / per)
            label = {"planks": "Planks (qualsiasi)", "log": "Log (qualsiasi)"}.get(fuel, pretty(fuel))
            print(f"   - {label:<20} {with_stacks(qty, fuel)}")
        print("  Nota: la carbonella si ottiene smeltando 1 log -> 1 carbonella.")
    print()


# ---------------------------------------------------------------- estensioni (usate dalla GUI)

# Stonecutter: 1 sorgente -> n pezzi.  (output, n, sorgente)
STONECUTTER = [
    ("stone_stairs", 1, "stone"), ("stone_slab", 2, "stone"), ("stone_bricks", 1, "stone"),
    ("stone_brick_stairs", 1, "stone_bricks"), ("stone_brick_slab", 2, "stone_bricks"),
    ("stone_brick_wall", 1, "stone_bricks"), ("chiseled_stone_bricks", 1, "stone_bricks"),
    ("smooth_stone_slab", 2, "smooth_stone"),
    ("cobblestone_stairs", 1, "cobblestone"), ("cobblestone_slab", 2, "cobblestone"),
    ("cobblestone_wall", 1, "cobblestone"),
    ("polished_andesite", 1, "andesite"), ("polished_diorite", 1, "diorite"),
    ("polished_granite", 1, "granite"),
    ("polished_deepslate", 1, "cobbled_deepslate"), ("deepslate_bricks", 1, "cobbled_deepslate"),
    ("deepslate_tiles", 1, "cobbled_deepslate"),
    ("polished_blackstone", 1, "blackstone"), ("polished_blackstone_bricks", 1, "blackstone"),
    ("brick_slab", 2, "bricks"), ("brick_stairs", 1, "bricks"),
    ("sandstone_slab", 2, "sandstone"), ("cut_sandstone", 1, "sandstone"),
    ("nether_brick_slab", 2, "nether_bricks"), ("nether_brick_stairs", 1, "nether_bricks"),
    ("quartz_slab", 2, "quartz_block"), ("quartz_pillar", 1, "quartz_block"),
    ("quartz_bricks", 1, "quartz_block"), ("chiseled_quartz_block", 1, "quartz_block"),
    ("cut_copper", 4, "copper_block"),
]


def apply_stonecutter(recipes):
    R = dict(recipes)
    for out, n, src in STONECUTTER:
        R[out] = (n, {src: 1}, "craft")
    return R


def fmt_time(sec):
    sec = int(round(sec))
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    return (f"{h}h " if h else "") + (f"{m}m " if h or m else "") + f"{s}s"


def solve(targets, recipes, have=None):
    """Come compute(), ma sottrae l'inventario (have) e restituisce un dizionario completo."""
    have = have or {}
    need = defaultdict(int)
    for k, v in targets.items():
        need[k] += v
    visited, post = set(), []

    def dfs(x):
        if x in visited:
            return
        visited.add(x)
        if x in recipes:
            for ing in recipes[x][1]:
                dfs(ing)
        post.append(x)

    for t in targets:
        dfs(t)
    order = list(reversed(post))
    runs, gross, used = {}, {}, {}
    for item in order:
        gross[item] = need[item]
        h = min(have.get(item, 0), need[item])
        if h:
            used[item] = h
            need[item] -= h
        if item in recipes and need[item] > 0:
            out, ing, _ = recipes[item]
            runs[item] = math.ceil(need[item] / out)
            for i, q in ing.items():
                need[i] += runs[item] * q
    raw = {i: need[i] for i in order if i not in recipes}
    steps = [i for i in reversed(order) if i in recipes and runs.get(i, 0) > 0]
    return {"need": dict(need), "gross": gross, "used": used, "runs": runs,
            "raw": raw, "steps": steps, "order": order}


def plan(targets, wood="oak", have=None, treat_raw=None, stonecutter=False,
         blast=False, mult=1, margin=0, furnaces=1, fuel="coal"):
    """Pipeline completa: opzioni -> ricette -> calcolo -> combustibile e tempi."""
    base = build_recipes(wood)
    known_raw = {i for (_, ing, _) in base.values() for i in ing if i not in base}
    recipes = apply_stonecutter(base) if stonecutter else dict(base)
    for k in (treat_raw or []):
        recipes.pop(k, None)
    tg = {k: -(-(v * mult * (100 + margin)) // 100) for k, v in targets.items() if v > 0}
    unknown = [t for t in tg if t not in base and t not in known_raw]
    p = solve(tg, recipes, have)
    smelt = ore = 0
    for item in p["steps"]:
        out, _, kind = recipes[item]
        n = p["runs"][item] * out
        if kind == "ore":
            ore += n
        elif kind == "smelt":
            smelt += n
    eff = smelt + ore * (0.5 if blast else 1)
    secs = (smelt * 10 + ore * (5 if blast else 10)) / max(1, furnaces)
    p.update(recipes=recipes, targets=tg, unknown=unknown, smelt=smelt, ore=ore,
             effective=eff, seconds=secs, furnaces=max(1, furnaces), blast=blast, fuel=fuel,
             fuels={f: math.ceil(eff / per) for f, per in FUELS.items()} if eff else {})
    return p


def plan_tree(p):
    R = p["recipes"]

    def node(item, qty):
        if item in R:
            out, ing, kind = R[item]
            runs = math.ceil(qty / out)
            return {"item": item, "qty": qty, "kind": kind, "runs": runs,
                    "children": [node(i, runs * q) for i, q in ing.items()]}
        return {"item": item, "qty": qty, "kind": "raw", "runs": 0, "children": []}

    return [node(t, n) for t, n in p["targets"].items()]


def plan_text(p, disp=None):
    disp = disp or with_stacks
    R, L, bar = p["recipes"], [], "=" * 64
    L += [bar, " OBIETTIVO", bar]
    for t, n in p["targets"].items():
        L.append(f"  {pretty(t)}: {disp(n, t)}")
    if p["unknown"]:
        L.append("  [!] Senza ricetta (trattati come materiali base): "
                 + ", ".join(pretty(u) for u in p["unknown"]))
    L += ["", bar, " MATERIALI BASE DA RACCOGLIERE", bar]
    for item, n in sorted(p["raw"].items(), key=lambda x: pretty(x[0])):
        extra = f"   (+{fmt(p['used'][item])} dal tuo inventario)" if item in p["used"] else ""
        L.append(f"  {pretty(item):<28} {disp(n, item)}{extra}")
    L += ["", bar, " PASSAGGI (in ordine di costruzione)", bar]
    for k, item in enumerate(p["steps"], 1):
        out, ing, kind = R[item]
        r = p["runs"][item]
        made = r * out
        extra = f"   (avanzo {fmt(made - p['need'][item])})" if made > p["need"][item] else ""
        uses = " + ".join(f"{fmt(r * q)} {pretty(i)}" for i, q in ing.items())
        if kind == "craft":
            L.append(f"{k:>3}. CRAFT {pretty(item)}: {fmt(r)} craft -> {fmt(made)} pezzi{extra}")
        else:
            L.append(f"{k:>3}. SMELT {pretty(item)}: {fmt(made)} pezzi{extra}")
        L.append(f"       usa: {uses}")
    if p["smelt"] + p["ore"]:
        L += ["", bar, " COMBUSTIBILE E TEMPI", bar]
        L.append(f"  Oggetti da smeltare: {fmt(p['smelt'] + p['ore'])}"
                 f"   |   fornaci: {p['furnaces']}   |   tempo stimato: {fmt_time(p['seconds'])}")
        for f, q in p["fuels"].items():
            mark = "  <-- scelto" if f == p["fuel"] else ""
            L.append(f"   - {pretty(f):<20} {disp(q, f)}{mark}")
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser(description="Calcolatore materiali Minecraft (Litematica).")
    ap.add_argument("items", nargs="*", help='es. chiseled_bookshelf=3000  oppure  "3000 glass"')
    ap.add_argument("-f", "--file", help="material list di Litematica (.csv o .txt)")
    ap.add_argument("--missing", action="store_true", help="usa la colonna 'Missing' invece di 'Total'")
    ap.add_argument("-w", "--wood", choices=WOODS, help="legno per le ricette generiche (default: oak)")
    ap.add_argument("--blast", action="store_true", help="smelta i minerali nel blast furnace")
    a = ap.parse_args()

    targets = defaultdict(int)
    if a.file:
        for k, v in load_file(a.file, a.missing).items():
            targets[k] += v
    for s in a.items:
        t = parse_target(s)
        if not t:
            print(f"Non capisco '{s}' (usa nome=quantita', es. glass=500)")
            sys.exit(1)
        targets[t[0]] += t[1]

    wood = a.wood
    if not targets:
        print("Inserisci gli oggetti (es. 'chiseled bookshelf 3000'). Invio vuoto per calcolare.")
        while True:
            s = input("> ").strip()
            if not s:
                break
            t = parse_target(s)
            if t:
                targets[t[0]] += t[1]
            else:
                print("  non capito, riprova (es. 'glass 500')")
        if not targets:
            return
        if wood is None:
            w = input(f"Tipo di legno {WOODS} (invio = oak): ").strip().lower().replace(" ", "_")
            wood = w if w in WOODS else "oak"
    wood = wood or "oak"

    report(dict(targets), build_recipes(wood), a.blast)


if __name__ == "__main__":
    main()
